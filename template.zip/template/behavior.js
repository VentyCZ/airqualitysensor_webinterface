
document.addEventListener("DOMContentLoaded", function () {
    //SETTINGS
    //INITIALIZE THE VARIABLES
    var settingsTimer = null; // Initialize a variable to store the timer ID

    const customReadTimeInput = document.getElementById('custom-read-time');
    const customReadTimeValue = document.getElementById('custom-read-time-value');


    const overallBrightnessInput = document.getElementById('overall-brightness');
    const overallBrightnessValue = document.getElementById('overall-brightness-value');

    const timeLEDOnInput = document.getElementById("time-led-on");
    const timeLEDOnValue = document.getElementById("time-led-on-value");

    const thresholdIndicatorInput = document.getElementById("threshold-indicator");
    const thresholdIndicatorValue = document.getElementById("threshold-indicator-value");

    const overrideValuesInput = document.getElementById("override-values");
    const overrideValuesValue = document.getElementById("override-values-value");

    //INIT AIR QUALITY SENSOR
    var onCurrentDataReceived = () => {
        document.querySelectorAll("#ppm10 .parameter-value")[0].innerHTML = "" + window.currentData.ppm10;
        document.querySelectorAll("#ppm2_5 .parameter-value")[0].innerHTML = "" + window.currentData.ppm2_5;
        document.querySelectorAll("#ppm1_0 .parameter-value")[0].innerHTML = "" + window.currentData.ppm1_0;
        document.querySelectorAll("#aqi .parameter-value")[0].innerHTML = "" + window.currentData.aqi;
        window.pJSDom[0].pJS.particles.number.value = map(window.currentData.aqi, 0, 200, 30, 5000);
        window.pJSDom[0].pJS.fn.particlesRefresh();

        visualizeData();
        
    }
    var onHistoricalDataReceived = () => {
        visualizeData();
       
    }
    window.addEventListener("resize", () => {

        visualizeData();
    });

    var onReceiveSettings = (newSettings) => {
        enableControls();
        
        if (newSettings.length >= 4) {
            var frequencyRead = newSettings[0] / (60 * 1000);
            customReadTimeInput.value = frequencyRead;


            overallBrightnessInput.value = newSettings[1]*100;

            var timeLedOn = newSettings[2] / 1000;
            timeLEDOnInput.value = timeLedOn;

            thresholdIndicatorInput.value = newSettings[3];
        }


    }

    air_quality_sensor.init(onCurrentDataReceived, onHistoricalDataReceived, onReceiveSettings);

    const feedbackBox = document.getElementById("settings-feedback-box");

    const checkIfSensorOnline = () => {
        window.setTimeout(() => {
            const displayValue = feedbackBox.style.display;
            if (displayValue.indexOf("none") == -1) {
                air_quality_sensor.querySettings();
                console.log("why is the sensor not online?");
                checkIfSensorOnline();

            }

        }, 2500);
    };
    checkIfSensorOnline();


    //BACKGROUND:
    particlesJS.load('particles-js', './particlesjs-config.json', function () {
        

    });


    /** ##TABS LOGIC */
    // TABS LOGIC
    // Get the tabs container and the tab content containers
    // JavaScript
    const tabsContainer = document.getElementById('tabs-container');
    const tabContents = document.querySelectorAll('.tab-content');
    const infoBtn = document.getElementById('info-btn');
    const closeBtn = document.getElementById('close-btn');

    infoBtn.addEventListener('click', () => {
        tabContents.forEach(tabContent => {
            tabContent.classList.remove('active');
        });
        initSettings();
        document.getElementById('tab2').classList.add('active');
    });

    closeBtn.addEventListener('click', () => {
        tabContents.forEach(tabContent => {
            tabContent.classList.remove('active');
        });

        document.getElementById('tab1').classList.add('active');
    });

     document.getElementById('tab1').classList.add('active');


    function visualizeData() {

        const container = document.getElementById('chart-container');
        container.innerHTML = ''; // Clear previous visualization

        for (let i = 0; i < window.historicalData.length; i++) {
            const day = window.historicalData[i];
            if (day) {
                const dayContainer = document.createElement('div');
                dayContainer.classList.add('day-container');

                const dayLabel = document.createElement('div');
                dayLabel.classList.add('day-label');
                dayLabel.textContent = window.aggregateData[i].timestamp;


                const canvas = document.createElement('canvas');
                canvas.width = document.documentElement.clientWidth - 60;
                canvas.height = 50;
                const ctx = canvas.getContext('2d');
                // Set text content and position for labels
                const labels = ['6am', '9am', '12pm', '3pm', '6pm', '9pm'];
                const labelHeight = 20;
                const labelX = canvas.width / 2 - labelHeight / 2;
                const labelYStep = canvas.height / 12;

                // Set line thickness and color for markings
                ctx.lineWidth = 1;
                ctx.strokeStyle = '#acacac55';

                // Clear the canvas before drawing
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                // Draw the background using a solid color
                ctx.fillStyle = '#dcdcdc55'; // Set the background color to light gray
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                // Calculate the distance between each marking based on the canvas height and the number of markings per day (12 * 2 = 24)
                const lineStep = canvas.height / 24;
                ctx.fillStyle = '#55555555'; // Set the background color to light gray
                // Use a loop to draw the markings and labels at the specified hours
                for (let i = 0; i < labels.length; i++) {

                    const label = labels[i];

                    const hour = parseInt(label);

                    // if (hour > 6 && hour<6.1 || hour == 9 || hour == 12 || hour == 3 || hour == 6 || hour == 9) {
                    // Draw the label at the specified position
                    let xTmp = (canvas.width / (labels.length + 1)) * (i + 1);
                    ctx.fillText(label, xTmp + 5, labelHeight - labelYStep);

                    // Draw a line for the marking at the specified position
                    ctx.beginPath();
                    ctx.moveTo(xTmp, 0);
                    ctx.lineTo(xTmp, canvas.height);
                    ctx.stroke();
                    // }
                }
                const y = 0;
                const width = canvas.width / 288;
                for (let j = 0; j < day.length; j++) {
                    const dataPoint = day[j];
                    if (dataPoint) {
                        const x = fractionOfDay(dataPoint.timestamp) * (canvas.width - width);

                        const aqi = AQIVal(dataPoint.value);
                        const height = map(aqi, 0, 200, 3, canvas.height);
                        const color = interpolateColors(aqi);
                        ctx.fillStyle = color;
                        ctx.fillRect(x, canvas.height - height, width, height);

                    }
                }

                canvas.addEventListener('mousemove', showDataPointValue);
                canvas.addEventListener('mouseout', hideTooltip);
                canvas.setAttribute('data-day', "" + i);
                dayContainer.appendChild(canvas);
                dayContainer.appendChild(dayLabel);
                container.appendChild(dayContainer);
            }
            const breakDiv = document.createElement('div');
            breakDiv.classList.add('break');
            container.appendChild(breakDiv);

        }
    }

    function showDataPointValue(e) {

        const canvas = e.target;
        const rect = canvas.getBoundingClientRect();
        const canvasX = e.clientX - rect.left;
        const canvasWidth = rect.width;

        // 1. Get the day index from the canvas parent element
        const dayIndex = canvas.getAttribute('data-day');
        const day = window.historicalData[dayIndex];

        if (!day) {
            hideTooltip();
            return;
        }

        // 2. Calculate the relative position in the day
        const relativePosition = canvasX / canvasWidth;
        var relativeHMS = hourMinuteSecondFromValue(relativePosition);
        var relativeDate = new Date(day[0].timestamp.getFullYear(), day[0].timestamp.getMonth(), day[0].timestamp.getDate(), relativeHMS.hours, relativeHMS.minutes, relativeHMS.seconds);

        // // 3. Find the closest data point
        var dataPoint;
        var minDiff = Infinity;
        for (let i = 0; i < day.length; i++) {
            const diffTmp = Math.abs(relativeDate.getTime() - day[i].timestamp.getTime());
            if (diffTmp >= 0 && diffTmp < 30 * 60 * 1000 && diffTmp < minDiff) { // Check if the difference is within 30 minutes
                dataPoint = day[i];
                minDiff = diffTmp;
            }
        }

        if (dataPoint == undefined) {
            hideTooltip();
            return;
        }
        var tooltip = document.getElementById("tooltip");

        // // 4. Update the tooltip content and position
        if (dataPoint) {
            tooltip.innerHTML = `<span class="tooltip-time">${padLeftZero(dataPoint.timestamp.getHours(), 2)}:${padLeftZero(dataPoint.timestamp.getMinutes(), 2)}</span> &#9; AQI: <span class="tooltip-val">${dataPoint.value}</span> <br>  ppm10: <span class="tooltip-val"> ${dataPoint.ppm10}</span> ppm2.5: <span class="tooltip-val">${dataPoint.ppm2_5}</span> ppm1.0: <span class="tooltip-val">${dataPoint.ppm1_0}</span>`;
        } else {
            tooltip.textContent = 'No data available for this time.';
        }
        if (window.innerWidth - e.clientX > tooltip.offsetWidth) {
            tooltip.style.left = `${e.clientX + 10}px`;

        }
        else {
            tooltip.style.left = `${e.clientX - (tooltip.offsetWidth + 10)}px`;
        }
        tooltip.style.top = `${e.clientY + 10}px`;
        tooltip.classList.add('visible');


    }

    function hideTooltip() {
        tooltip.classList.remove('visible');
    }







    /* clearTimeout(settingsTimer); // Clear any existing timer when an
interaction occurs
    updateLastInteraction(); // Set a new timeout for 2 seconds after the 
interaction
 */

    const disableControls = () => {


        document.getElementById("settings-container").style.display = "";
        feedbackBox.style.display = "";
        document.getElementById("active-settings").style.display = "none";
        document.querySelectorAll('.setting-item input[type="range"], .setting-item button, .setting-item input[type = "checkbox"]').forEach(control => {
            control.classList.add('disabled');
            control.disabled = true; // Add a disabled attribute to the elements as well
            // control.nextElementSibling.classList.add('grayedOut'); // Add the "grayedOut" class to the corresponding label and value display
        });
        document.querySelectorAll("label").forEach(label => {
            label.classList.add('grayedOut');
        });
        document.querySelectorAll(".control-value").forEach(control => {
            control.classList.add("grayedOut");
        });
        document.getElementById("update-settings-button").style.display = "none";
     
    };
    disableControls();
    const enableControls = () => {
        // Set the display property to 'none'
        feedbackBox.style.display = "none";

        document.getElementById("settings-container").style.display = "block";

        document.querySelectorAll('.setting-item input, .setting-item input, button').forEach(control => {
            control.classList.remove('disabled');
            control.disabled = false; // Remove the disabled attribute from the elements
            // control.nextElementSibling.classList.remove('grayedOut'); // Remove the "grayedOut" class from the corresponding label and value display
        });
        document.querySelectorAll("label").forEach(label => {
            label.classList.remove('grayedOut');
        });
        document.querySelectorAll(".control-value").forEach(control => {
            control.classList.remove("grayedOut");
        });
        document.getElementById("update-settings-button").style.display = "";
        
    };

    // Update custom read time value
    customReadTimeInput.addEventListener('input', function () {
        const minutes = parseInt(this.value, 10);
        customReadTimeValue.textContent = `${minutes} minutes`;
    });

    //Update threshold indicator value
    thresholdIndicatorInput.addEventListener('input', function () {
        const thresholdPPm = parseInt(this.value, 10);
        thresholdIndicatorValue.textContent = `${thresholdPPm} AQI`;
    });
    //Update debug ppm override
    overrideValuesInput.addEventListener('input', function () {
        const ppmOPverride = parseInt(this.value, 10);
        overrideValuesValue.textContent = `${ppmOPverride}`;
    });
    // Update overall brightness value
    overallBrightnessInput.addEventListener('input', function () {
        const brightness = parseInt(this.value, 10);
        overallBrightnessValue.textContent = `${brightness}%`;
    });
    timeLEDOnInput.addEventListener('input', function () {
        const time = parseInt(this.value, 10);
        timeLEDOnValue.textContent = `${time} seconds `;
    });
    const initSettings = () => {
        // Get all elements with the class "settings-group"
        const settingGroups = document.querySelectorAll(".settings-group");
        air_quality_sensor.querySettings();

        //SET TIMEZONE
        const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
        console.log(`Current timezone: ${tz}`);

        const offset = -new Date().getTimezoneOffset();
        console.log(`Timezone offset (minutes): ${offset}`);

    };


    document.getElementById("update-settings-button").addEventListener("click", () => {

        var frequencyRead = (customReadTimeInput.value * 60 * 1000);
        
        var overallBrightness = overallBrightnessInput.value /100.0;
        var timeLedOn = timeLEDOnInput.value * 1000;
        var thresholdIndicator = thresholdIndicatorInput.value - 0;

        air_quality_sensor.setSettings(frequencyRead, overallBrightness, timeLedOn, thresholdIndicator);
    });
    
    document.getElementById("override-ppm2_5-button").addEventListener("click", () => {
        air_quality_sensor.debugOverrideCurrentAQI(document.getElementById("override-values").value);
    });

    const updateLastInteraction = () => {
        settingsTimer = setTimeout(() => {
            air_quality_sensor.querySettings(); // Call querySettings after 2 seconds of inactivity
        }, 2000); // Set the timeout to 2 seconds
    };

    //RESET DEFAULS
    document.getElementById("reset-defaults").addEventListener("click", function (event) {
        air_quality_sensor.resetDefaultSettings();
    });

    //PLAY ANIMATION
    document.getElementById('playStartAnimation').addEventListener('click', function (event) {

        air_quality_sensor.debugPlayStartAnimation();

    });

    //HIDE ADVANCED SETTIGNS
    //SHOW ADVANCED SETTINGS
    var isShowingSettings = false;
    document.getElementById("button-advanced-settings").addEventListener("click",function(){
        if (isShowingSettings)
        {
            //change button label 
            document.getElementById("button-advanced-settings").textContent = "Show settings";
            const settingsBox = document.getElementById('active-settings');
            settingsBox.style.display = "none";
            
        }
        else
        {
            document.getElementById("button-advanced-settings").textContent = "Hide settings";
            
            const settingsBox = document.getElementById('active-settings');
            settingsBox.style.display = "";
        }
        isShowingSettings = !isShowingSettings;
    });

    console.log("loaded");
    document.getElementById("loading").style.display = "none";


});
