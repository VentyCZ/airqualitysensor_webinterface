document.addEventListener("DOMContentLoaded", function () {

    //BACKGROUND:
    particlesJS.load('particles-js', './particlesjs-config.json', function () {
        console.log('callback - particles.js config loaded');

    });

    /** ##TABS LOGIC */
    // TABS LOGIC
    // Get the tabs container and the tab content containers
    const tabsContainer = document.getElementById('tabs-container');
    const tabContents = document.querySelectorAll('.tab-content');
    const tabButtons = document.querySelectorAll('.tab-button');

    // Add event listener to the tabs container
    tabsContainer.addEventListener('click', e => {
        // Check if the clicked element is a tab button
        if (e.target.classList.contains('tab-button')) {
            // Remove the active class from all tab buttons
            tabButtons.forEach(tabButton => {
                tabButton.classList.remove('active');
            });

            // Add the active class to the clicked tab button
            e.target.classList.add('active');

            // Remove the active class from all tab content containers
            tabContents.forEach(tabContent => {
                tabContent.classList.remove('active');
            });

            // Get the ID of the clicked tab
            const tabId = e.target.getAttribute('href');

            // Add the active class to the corresponding tab content container
            document.querySelector(tabId).classList.add('active');
            console.log(tabId);
            if(tabId == "")
            {

            }
            // Prevent the default link behavior
            e.preventDefault();
        }
    });

    tabButtons[0].click();

    //GLOBAL VARIABLES
    window.historicalData = [];
    window.aggregateData = [];


    //WEBSOCKET LOGIC

    let socket = new WebSocket('ws://' + window.location.host + '/ws');
    socket.addEventListener("message", (event) => {
        var data;
        try {
            data = JSON.parse(event.data);
        } catch (e) {
            console.log("received", event.data);
            console.warn(e);
            return;
        }
        if (!data.hasOwnProperty("m")) {
            console.warn("JSON format not recognized");
            return;
        }
        if (data.m === "currentData") {
            //UPDATE INTERFACE
            var aqiTmp = AQIVal(data.v[7]);
            document.querySelectorAll("#ppm10 .parameter-value")[0].innerHTML = "" + data.v[6];
            document.querySelectorAll("#ppm2_5 .parameter-value")[0].innerHTML = "" + data.v[7];
            document.querySelectorAll("#ppm1_0 .parameter-value")[0].innerHTML = "" + data.v[8];
            document.querySelectorAll("#aqi .parameter-value")[0].innerHTML = "" + aqiTmp;


            window.pJSDom[0].pJS.particles.number.value = map(aqiTmp, 0, 200, 30, 5000);
            window.pJSDom[0].pJS.fn.particlesRefresh();

        } else if (data.m === "historical") {
            processHistoricalData(data.v);
            visualizeData();
            addEventListener("resize", (event) => {

                visualizeData();

            });
        }
        else if (data.m == "settings") {
            console.log("gotten settings", data.v);
            enableControls();
        }
    });

    function processHistoricalData(data) {
        const result = data.reduce((acc, val, i) => {
            if (i % 11 === 0) {
                acc.push([val]);
            } else {
                acc[acc.length - 1].push(val);
            }
            return acc;
        }, []);

        const now = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 0, 1, 0);

        var keyDateTmp;
        var dayDateTmp;
        for (let element of result) {

            keyDateTmp = new Date(element[0], element[1] - 1, element[2], element[3], element[4], 0);
            dayDateTmp = new Date(element[0], element[1] - 1, element[2], 0, 1, 0);


            let dateDiffIndex = dateDiffInDays(dayDateTmp, now);

            if (!window.historicalData[dateDiffIndex]) {
                window.historicalData[dateDiffIndex] = [];
            }

            let timeIndex = getTimeIndex(keyDateTmp);
            let dataPoint = {
                timestamp: keyDateTmp,
                value: AQIVal(element[7]),
                ppm2_5: element[7],
                ppm10: element[8],
                ppm1_0: element[6]
            };

            window.historicalData[dateDiffIndex].push(dataPoint);

            if (window.aggregateData[dateDiffIndex] == undefined && dayDateTmp != undefined) {
                window.aggregateData[dateDiffIndex] = { timestamp: getDateString(dayDateTmp), date: dayDateTmp };
            }
        }
    }

    function visualizeData() {

        const container = document.getElementById('chart-container');
        container.innerHTML = ''; // Clear previous visualization

        for (let i = 0; i < window.historicalData.length; i++) {
            const day = window.historicalData[i];
            if (day) {
                const dayContainer = document.createElement('div');
                dayContainer.classList.add('day-container');

                const dayLabel = document.createElement('div');
                dayLabel.classList.add('day-label');
                dayLabel.textContent = window.aggregateData[i].timestamp;


                const canvas = document.createElement('canvas');
                canvas.width = document.documentElement.clientWidth - 60;
                canvas.height = 50;
                const ctx = canvas.getContext('2d');
                // Set text content and position for labels
                const labels = ['6am', '9am', '12pm', '3pm', '6pm', '9pm'];
                const labelHeight = 20;
                const labelX = canvas.width / 2 - labelHeight / 2;
                const labelYStep = canvas.height / 12;

                // Set line thickness and color for markings
                ctx.lineWidth = 1;
                ctx.strokeStyle = '#acacac55';

                // Clear the canvas before drawing
                ctx.clearRect(0, 0, canvas.width, canvas.height);

                // Draw the background using a solid color
                ctx.fillStyle = '#dcdcdc55'; // Set the background color to light gray
                ctx.fillRect(0, 0, canvas.width, canvas.height);

                // Calculate the distance between each marking based on the canvas height and the number of markings per day (12 * 2 = 24)
                const lineStep = canvas.height / 24;
                ctx.fillStyle = '#55555555'; // Set the background color to light gray
                // Use a loop to draw the markings and labels at the specified hours
                for (let i = 0; i < labels.length; i++) {

                    const label = labels[i];

                    const hour = parseInt(label);

                    // if (hour > 6 && hour<6.1 || hour == 9 || hour == 12 || hour == 3 || hour == 6 || hour == 9) {
                    // Draw the label at the specified position
                    let xTmp = (canvas.width / (labels.length + 1)) * (i + 1);
                    ctx.fillText(label, xTmp+5, labelHeight-labelYStep);

                    // Draw a line for the marking at the specified position
                    ctx.beginPath();
                    ctx.moveTo(xTmp, 0);
                    ctx.lineTo(xTmp, canvas.height);
                    ctx.stroke();
                    // }
                }
                const y = 0;
                const width = canvas.width / 288;
                for (let j = 0; j < day.length; j++) {
                    const dataPoint = day[j];
                    if (dataPoint) {
                        const x = fractionOfDay(dataPoint.timestamp) * (canvas.width - width);

                        const aqi = AQIVal(dataPoint.value);
                        const height = map(aqi, 0, 200, 3, canvas.height);
                        const color = interpolateColors(aqi);
                        ctx.fillStyle = color;
                        ctx.fillRect(x, canvas.height - height, width, height);

                    }
                }

                canvas.addEventListener('mousemove', showDataPointValue);
                canvas.addEventListener('mouseout', hideTooltip);
                canvas.setAttribute('data-day', "" + i);
                dayContainer.appendChild(canvas);
                dayContainer.appendChild(dayLabel);
                container.appendChild(dayContainer);
            }
            const breakDiv = document.createElement('div');
            breakDiv.classList.add('break');
            container.appendChild(breakDiv);

        }
    }




    function showDataPointValue(e) {

        const canvas = e.target;
        const rect = canvas.getBoundingClientRect();
        const canvasX = e.clientX - rect.left;
        const canvasWidth = rect.width;

        // 1. Get the day index from the canvas parent element
        const dayIndex = canvas.getAttribute('data-day');
        const day = window.historicalData[dayIndex];

        if (!day) {
            hideTooltip();
            return;
        }

        // 2. Calculate the relative position in the day
        const relativePosition = canvasX / canvasWidth;
        var relativeHMS = hourMinuteSecondFromValue(relativePosition);
        var relativeDate = new Date(day[0].timestamp.getFullYear(), day[0].timestamp.getMonth(), day[0].timestamp.getDate(), relativeHMS.hours, relativeHMS.minutes, relativeHMS.seconds);

        // // 3. Find the closest data point
        var dataPoint;
        var minDiff = Infinity;
        for (let i = 0; i < day.length; i++) {
            const diffTmp = Math.abs(relativeDate.getTime() - day[i].timestamp.getTime());
            if (diffTmp >= 0 && diffTmp < 30 * 60 * 1000 && diffTmp < minDiff) { // Check if the difference is within 30 minutes
                dataPoint = day[i];
                minDiff = diffTmp;
            }
        }

        if (dataPoint == undefined) {
            hideTooltip();
            return;
        }
        var tooltip = document.getElementById("tooltip");

        // // 4. Update the tooltip content and position
        if (dataPoint) {
            tooltip.innerHTML = `<span class="tooltip-time">${padLeftZero(dataPoint.timestamp.getHours(), 2)}:${padLeftZero(dataPoint.timestamp.getMinutes(), 2)}</span> &#9; AQI: <span class="tooltip-val">${dataPoint.value}</span> <br>  ppm10: <span class="tooltip-val"> ${dataPoint.ppm10}</span> ppm2.5: <span class="tooltip-val">${dataPoint.ppm2_5}</span> ppm1.0: <span class="tooltip-val">${dataPoint.ppm1_0}</span>`;
        } else {
            tooltip.textContent = 'No data available for this time.';
        }
        if (window.innerWidth - e.clientX > tooltip.offsetWidth) {
            tooltip.style.left = `${e.clientX + 10}px`;

        }
        else {
            tooltip.style.left = `${e.clientX - (tooltip.offsetWidth + 10)}px`;
        }
        tooltip.style.top = `${e.clientY + 10}px`;
        tooltip.classList.add('visible');


    }

    function hideTooltip() {
        tooltip.classList.remove('visible');
    }


    //SETTINGS
    //CUSTOM SETTINGS
    var settingsTimer = null; // Initialize a variable to store the timer ID

    const customReadTimeInput = document.getElementById('custom-read-time');
    const customReadTimeValue = document.getElementById('custom-read-time-value');

    const getTimeFromServerCheckbox = document.getElementById('get-time-from-server');
    const sensorTimeGroup = document.getElementById('sensor-time-group');

    const timeZoneSelect = document.getElementById("timezone-select");

    const overallBrightnessInput = document.getElementById('overall-brightness');
    const overallBrightnessValue = document.getElementById('overall-brightness-value');

    const autobrightnessInput = document.getElementById("autobrightness");

    const timeLEDOnInput = document.getElementById("time-led-on");
    const timeLEDOnValue = document.getElementById("time-led-on-value");

    const thresholdIndicatorInput = document.getElementById("threshold-indicator");
    const thresholdIndicatorValue = document.getElementById("threshold-indicator-value");

    const overrideValuesInput = document.getElementById("override-values");
    const overrideValuesValue = document.getElementById("override-values-value");




    /* clearTimeout(settingsTimer); // Clear any existing timer when an
interaction occurs
    updateLastInteraction(); // Set a new timeout for 2 seconds after the 
interaction
 */

    const disableControls = () => {
        document.querySelectorAll('.setting-item input[type="range"], .setting-item button, .setting-item input[type = "checkbox"]').forEach(control => {
            control.classList.add('disabled');
            console.log("disable ", control);
            control.disabled = true; // Add a disabled attribute to the elements as well
            // control.nextElementSibling.classList.add('grayedOut'); // Add the "grayedOut" class to the corresponding label and value display
        });
        document.querySelectorAll("label").forEach(label => {
            label.classList.add('grayedOut');
        });
        document.querySelectorAll(".control-value").forEach(control => {
            control.classList.add("grayedOut");
        });
    };
    disableControls();
    const enableControls = () => {
        document.querySelectorAll('.setting-item input, .setting-item input, button').forEach(control => {
            control.classList.remove('disabled');
            control.disabled = false; // Remove the disabled attribute from the elements
            // control.nextElementSibling.classList.remove('grayedOut'); // Remove the "grayedOut" class from the corresponding label and value display
        });
    };

    // Update custom read time value
    customReadTimeInput.addEventListener('input', function () {
        const minutes = parseInt(this.value, 10);
        customReadTimeValue.textContent = `${minutes} minutes`;
    });

    // Toggle sensor time group
    getTimeFromServerCheckbox.addEventListener('change', function () {
        sensorTimeGroup.classList.toggle('disabled', this.checked);
    });
    //Update threshold indicator value
    thresholdIndicatorInput.addEventListener('input', function () {
        const thresholdPPm = parseInt(this.value, 10);
        thresholdIndicatorValue.textContent = `${thresholdPPm}`;
    });
    //Update debug ppm override
    overrideValuesInput.addEventListener('input', function () {
        const ppmOPverride = parseInt(this.value, 10);
        overrideValuesValue.textContent = `${ppmOPverride}`;
    });
    // Update overall brightness value
    overallBrightnessInput.addEventListener('input', function () {
        const brightness = parseInt(this.value, 10);
        overallBrightnessValue.textContent = `${brightness}%`;
    });
    const initSettings = () => {
        // Get all elements with the class "settings-group"
        const settingGroups = document.querySelectorAll(".settings-group");

        // Hide each selected element
        for (const group of settingGroups) {
            group.style.display = 'none';
        }
        const debugGroup = document.querySelectorAll(".debug");

        // Hide each selected element
        for (const group of debugGroup) {
            group.style.display = 'block';
        }
        enableControls();
    };
    initSettings();
    //communication settings
    const querySettings = () => {
        var message = {
            m: "querySettings",
            v: "payload"
        };
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
            console.log("load settings", message);
        }
    };

    const setSettings = () => {
        //ORDER IS THE FOLLOWING: 
        //read time, auto time, timezone, autobrightness, overall brightness, time led on, threshold indicator

        var message = {
            m: "settingsUpdate",
            v: [(customReadTimeInput.value * 60),
            ((getTimeFromServerCheckbox.value == "on") ? 1 : 0),
            timeZoneSelect.selectedOptions[0].attributes["data-timediff"].value,
            ((autobrightnessInput.value == "on") ? 1 : 0),
            overallBrightnessInput.value,
            timeLEDOnInput.value,
            thresholdIndicatorInput.value]
        };

        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
            console.log("settings update", message);
        }

    }
    // document.getElementById("debug-update-settings").addEventListener("click", () => {
    //     setSettings();
    // });
    // document.getElementById("debug-load-settings").addEventListener("click", () => {
    //     querySettings();
    // });
    document.getElementById("override-ppm2_5-button").addEventListener("click", () => {
        var message = {
            m: "overrideValue",
            v: document.getElementById("override-values").value
        };
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
            console.log("override ppm", message);
        }
    });
    const updateLastInteraction = () => {
        settingsTimer = setTimeout(() => {
            querySettings(); // Call querySettings after 2 seconds of inactivity
        }, 2000); // Set the timeout to 2 seconds
    };



    //UPDATE TIME

    document.getElementById('updateTime').addEventListener('click', function (event) {
        var now = new Date();
        var hour = now.getHours();
        var min = now.getMinutes();
        var sec = now.getSeconds();
        var mday = now.getDate();
        var mon = now.getMonth() + 1; // months are zero-indexed, so add 1
        var year = now.getFullYear();
        var wday = now.getDay();

        // Create the time update message
        var message = {
            m: "timeUpdate",
            v: hour + "," + min + "," + sec + "," + mday + "," + mon + "," + year + "," + wday
        };

        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
        }
    });

    //PLAY ANIMATION
    document.getElementById('playStartAnimation').addEventListener('click', function (event) {
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            var message = {
                m: "playAnimation",
                v: "start"
            };
            socket.send(JSON.stringify(message));
        }
    });

    //CLOCK
    function updateClock() {
        const clock = document.getElementById('digital-clock');
        const now = new Date();
        const hours = now.getHours().toString().padStart(2, '0');
        const minutes = now.getMinutes().toString().padStart(2, '0');
        const seconds = now.getSeconds().toString().padStart(2, '0');
        const timeString = `${hours}:${minutes}:${seconds}`;
        clock.textContent = timeString;
    }

    setInterval(updateClock, 1000);
});
