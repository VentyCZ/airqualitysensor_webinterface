//GLOBAL VARIABLES
window.historicalData = [];
window.aggregateData = [];
window.currentData = {};

const air_quality_sensor = (() => {
    //PRIVATE VARIABLE
    let socket = new WebSocket('ws://' + window.location.host + '/ws');
  
    // let socket = new WebSocket('ws://' +"airqualityhallway.local" + '/ws');
    var callbackOnReceiveCurrentData, callbackOnReceiveHistoricalData, callbackOnReceiveSettings;
    var init = function (onReceiveCurrentData, onReceiveHistoricalData, onReceiveSettings) {
        //CONNECT WITH THE BOARD VIA WEBSOCKETS
        callbackOnReceiveCurrentData = onReceiveCurrentData;
        callbackOnReceiveHistoricalData = onReceiveHistoricalData;
        callbackOnReceiveSettings = onReceiveSettings;

        socket.addEventListener("message", (event) => {
            var data;
            try {
                data = JSON.parse(event.data);
            } catch (e) {
                console.log("received", event.data);
                console.warn(e);
                return;
            }
            if (!data.hasOwnProperty("m")) {
                console.warn("JSON format not recognized");
                return;
            }
            if (data.m === "currentData") {
                //UPDATE INTERFACE
                window.currentData.aqi = AQIVal(data.v[7]);
                window.currentData.ppm10 = data.v[6];
                window.currentData.ppm2_5 = data.v[7];
                window.currentData.ppm1_0 = data.v[8];
                onReceiveCurrentData();

            } else if (data.m === "historical") {
                processHistoricalData(data.v);
                onReceiveHistoricalData();
            }
            else if (data.m == "settings") {
                onReceiveSettings(data.v);

            }
        });
    }

    function processHistoricalData(data) {
        const result = data.reduce((acc, val, i) => {
            if (i % 11 === 0) {
                acc.push([val]);
            } else {
                acc[acc.length - 1].push(val);
            }
            return acc;
        }, []);

        const now = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 0, 1, 0);
        console.log("generating today's date:",now);

        var keyDateTmp;
        var dayDateTmp;
        var index = 0;
        for (let element of result) {

            // keyDateTmp = new Date(element[0], element[1] - 1, element[2], element[3], element[4], 0);
            // Create a new Date instance with the UTC time
            const utcDate = new Date(Date.UTC(element[0], element[1] - 1, element[2], element[3], element[4], 0));

            // Convert the UTC date to the local time zone
            keyDateTmp = new Date(utcDate.toLocaleString());
            
            console.log(index,"element's date - adjusted",keyDateTmp,element);
            // You can now use localDate to display or work with the local time
            
            dayDateTmp = new Date(keyDateTmp.getFullYear(), keyDateTmp.getMonth(), keyDateTmp.getDate(), 0, 1, 0);

            let dateDiffIndex = dateDiffInDays(dayDateTmp, now);

            if (!window.historicalData[dateDiffIndex]) {
                window.historicalData[dateDiffIndex] = [];
            }
            
            // let timeIndex = getTimeIndex(keyDateTmp);
            let dataPoint = {
                timestamp: keyDateTmp,
                value: AQIVal(element[7]),
                ppm2_5: element[7],
                ppm10: element[8],
                ppm1_0: element[6]
            };

            window.historicalData[dateDiffIndex].push(dataPoint);

            if (window.aggregateData[dateDiffIndex] == undefined && dayDateTmp != undefined) {
                

                window.aggregateData[dateDiffIndex] = { timestamp: getDateString(keyDateTmp), date: keyDateTmp };
            }
            index++;
        }
    }

    //communication settings
    const querySettings = () => {
        var message = {
            m: "querySettings",
            v: "payload"
        };
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));

        }
    };

    const setSettings = (frequencyReadTime, autoFetchTime, timezone, autobrightness, overallBrightness, timeLedOn, thresholdIndicator) => {

        var message = {
            m: "settingsUpdate",
            v: frequencyReadTime + "," + autoFetchTime + "," + timezone + "," + autobrightness + "," + overallBrightness + "," + timeLedOn + "," +thresholdIndicator
        };
        
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
            console.log("settings update", message);
        }

    }
    var playStartAnimation = () => {
        var message = {
            m: "playAnimation",
            v: "start"
        };
        socket.send(JSON.stringify(message));
    }
    var resetDefaultSettings = () => {
        var message = {
            m: "resetDefaults",
            v: "payload"
        };
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
        }
    }
    var overrideCurrentAQI = (newValue) => {
        var message = {
            m: "overrideValue",
            v: newValue
        };
        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
        }
    }
    var syncTime = () => {
        var now = new Date();
        var hour = now.getHours();
        var min = now.getMinutes();
        var sec = now.getSeconds();
        var mday = now.getDate();
        var mon = now.getMonth() + 1; // months are zero-indexed, so add 1
        var year = now.getFullYear();
        var wday = now.getDay();


        var message = {
            m: "timeUpdate",
            v: hour + "," + min + "," + sec + "," + mday + "," + mon + "," + year + "," + wday
        };

        if (socket.readyState === WebSocket.OPEN) {
            // Send the message as a JSON string
            socket.send(JSON.stringify(message));
        }
    }
    //EXPORT PUBLIC VARIABLES
    return {
        init: init,
        setSettings: setSettings,
        querySettings: querySettings,
        debugOverrideCurrentAQI: overrideCurrentAQI,
        debugPlayStartAnimation: playStartAnimation,
        resetDefaultSettings: resetDefaultSettings,
        syncTime: syncTime,

    }

})();
/*************** TIME UTILS **********************/
function padLeftZero(inputNumber, desiredLength) {
    // Convert input number to a string
    const numberAsString = String(inputNumber);

    // Create an array with 'length' elements, each filled with the character '0'
    const leadingZeroes = Array(desiredLength).fill('0');

    // Combine the 'leadingZeroes' and 'numberAsString' using the concatenation operator (+)
    const paddedNumber = leadingZeroes.join('') + numberAsString;

    // Extract only the last 'desiredLength' digits of the 'paddedNumber' string
    return paddedNumber.slice(-desiredLength);
}
function hourMinuteSecondFromValue(value) {
    const hours = Math.floor(value * 24); // Multiply by the total number of hours in a day and get the floor value
    const minutesRemainder = ((value * 24) % 1) * 60; // Calculate the fractional part of an hour
    const minutes = Math.floor(minutesRemainder); // Get the floor value for minutes
    const secondsRemainder = (value * 24 * 60) % 60; // Calculate the fractional part of a minute
    const seconds = Math.round(secondsRemainder); // 

    return { hours, minutes, seconds };
}
function getDifferenceInSecondsToGMT() {
    let currentTime = new Date().getTime();

    // Get the current time in GMT 0
    let gmtTime = new Date().toUTCString();

    // Calculate the time difference in seconds
    let timeDifferenceInSeconds = (currentTime - Date.parse(gmtTime)) / 1000;

    console.log("The difference in seconds between your local time and GMT 0 is: " + timeDifferenceInSeconds + " seconds.");
    return timeDifferenceInSeconds;
}


const getTimezoneOffsetFromGMT = () => {
    console.log("difference:", getDifferenceInSecondsToGMT());
    console.log(Intl.DateTimeFormat().resolvedOptions().timeZone);
    var offset = new Date().getTimezoneOffset();
    console.log("offset", offset);
    return offset;
}

const toUnixTime = (year, month, day, hr, min, sec) => {
    const date = new Date(Date.UTC(year, month - 1, day, hr, min, sec));
    return Math.floor(date.getTime() / 1000);
}

function getTimeIndex(date) {
    // Get the hours, minutes, and seconds from the date
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const seconds = date.getSeconds();

    // Calculate the total minutes since midnight
    const totalMinutes = (hours * 60) + minutes + (seconds / 60);

    // Calculate the index based on 5-minute chunks (0-287)
    const index = Math.floor(totalMinutes / 5);

    return index;
}
function dateDiffInDays(a, b) {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    // Discard the time and time-zone information.
    const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());

    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
}

function getDateString(newDate) {

    var timestamp = "";
    try {
        // Get the day of the week
        const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        const dayOfWeek = daysOfWeek[newDate.getDay()];

        // Get the month
        const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        const month = monthNames[newDate.getMonth()];

        // Get the day of the month
        const day = newDate.getDate();

        // Get the ordinal suffix (st, nd, rd, th)
        const ordinalSuffix = getOrdinalSuffix(day);

        // Construct the timestamp string
        timestamp = `${dayOfWeek} ${month} ${day}${ordinalSuffix}`;
    }
    catch (e) {
        console.warn(e);
    }

    return timestamp;
}

// Helper function to get the ordinal suffix for a day
function getOrdinalSuffix(day) {
    const lastDigit = day % 10;
    const lastTwoDigits = day % 100;

    if (lastTwoDigits >= 11 && lastTwoDigits <= 13) {
        return 'th';
    } else if (lastDigit === 1) {
        return 'st';
    } else if (lastDigit === 2) {
        return 'nd';
    } else if (lastDigit === 3) {
        return 'rd';
    } else {
        return 'th';
    }
}
function fractionOfDay(date) {
    /**
     * Returns a float between 0 and 1 representing the fraction of the day
     * that has elapsed for the given date.
     *
     * @param {Date} date - A Date object representing the date and time.
     * @returns {number} A float between 0 and 1 representing the fraction of the day.
     */

    // Get the hour, minute, and second components of the input date
    const hour = date.getHours();
    const minute = date.getMinutes();
    const second = date.getSeconds();

    // Calculate the total number of seconds elapsed since midnight
    const totalSeconds = hour * 3600 + minute * 60 + second;

    // Calculate the fraction of the day by dividing the elapsed seconds
    // by the total number of seconds in a day (24 * 60 * 60)
    const fraction = totalSeconds / (24 * 3600);

    return fraction;
}
/*************** GRAPHIC UTILS **********************/
function createTexture(numbers) {
    // Create a canvas element
    const canvas = document.createElement('canvas');
    canvas.width = 576;
    canvas.height = 40;

    // Get the 2D rendering context
    const ctx = canvas.getContext('2d');

    // Draw the stripes
    for (let i = 0; i < canvas.width; i += 2) {
        const x = i;
        const y = 0;
        const width = 2;
        const height = 40;
        const valueTmp = numbers[i];
        if (valueTmp == undefined) {
            ctx.fillStyle = `rgb(9,9,9)`;
            ctx.fillRect(x, y, width, height);
        }
        else {
            const color = interpolateColors(AQIVal(valueTmp) / 2.0);
            ctx.fillStyle = color;
            ctx.fillRect(x, y, width, height);
        }
    }

    // Return the canvas as an image data URL
    return canvas.toDataURL();
}
function interpolateColors(value) {
    if (value == 0) {
        value = 1.0;
    }
    // Define the 5 colors as RGB values
    const colors = [
        [1, 233, 0],   // Green
        [218, 200, 13], // Yellow
        [248, 112, 0],   // orange
        [204, 0, 10],   // red
        [217, 26, 137], // Magenta
        [126, 0, 35], // Maroon
    ];
    const extremes = [
        [0, 50],
        [51, 100],
        [101, 150],
        [151, 200],
        [201, 300],
        [301, 1000]
    ];
    if (value >= extremes[0][0] && value <= extremes[0][1]) {
        rVal = map(value, extremes[0][0], extremes[0][1], colors[0][0], colors[0][0]);
        gVal = map(value, extremes[0][0], extremes[0][1], colors[0][1], colors[0][1]);
        bVal = map(value, extremes[0][0], extremes[0][1], colors[0][2], colors[0][2]);

    } else if (value >= extremes[1][0] && value <= extremes[1][1]) {
        rVal = map(value, extremes[1][0], extremes[1][1], colors[0][0], colors[1][0]);
        gVal = map(value, extremes[1][0], extremes[1][1], colors[0][1], colors[1][1]);
        bVal = map(value, extremes[1][0], extremes[1][1], colors[0][2], colors[1][2]);

    } else if (value >= extremes[2][0] && value <= extremes[2][1]) {
        rVal = map(value, extremes[2][0], extremes[2][1], colors[1][0], colors[2][0]);
        gVal = map(value, extremes[2][0], extremes[2][1], colors[1][1], colors[2][1]);
        bVal = map(value, extremes[2][0], extremes[2][1], colors[1][2], colors[2][2]);

    } else if (value >= extremes[3][0] && value <= extremes[3][1]) {
        rVal = map(value, extremes[3][0], extremes[3][1], colors[2][0], colors[3][0]);
        gVal = map(value, extremes[3][0], extremes[3][1], colors[2][1], colors[3][1]);
        bVal = map(value, extremes[3][0], extremes[3][1], colors[2][2], colors[3][2]);;
    }
    else if (value >= extremes[4][0] && value <= extremes[4][1]) {
        rVal = map(value, extremes[4][0], extremes[4][1], colors[3][0], colors[4][0]);
        gVal = map(value, extremes[4][0], extremes[4][1], colors[3][1], colors[4][1]);
        bVal = map(value, extremes[4][0], extremes[4][1], colors[3][2], colors[4][2]);

    }
    else if (value > 300) {
        rVal = colors[5][0];
        gVal = colors[5][1];
        bVal = colors[5][2];
    }



    // Return the interpolated color as an RGB string
    return `rgb(${rVal}, ${gVal}, ${bVal})`;
}
function AQIVal(ppmVal) {
    let AQIvalue;

    ppmVal *= 10;

    if (ppmVal <= 120.0) {
        // 0-50 AQI | Green | Good
        AQIvalue = map(ppmVal, 0.0, 120.0, 0.0, 500.0);
    } else if (ppmVal > 120.0 && ppmVal <= 354.0) {
        // 51-100 AQI | Yellow | Moderate
        AQIvalue = map(ppmVal, 120.0, 354.0, 510.0, 1000.0);
    } else if (ppmVal > 354.0 && ppmVal <= 554.0) {
        // 101-150 AQI | Orange | Unhealthy for sensitive groups
        AQIvalue = map(ppmVal, 354.0, 554.0, 1010.0, 1500.0);
    } else if (ppmVal > 554.0 && ppmVal <= 1504.0) {
        // 151-200 AQI | Red | Unhealthy
        AQIvalue = map(ppmVal, 554.0, 1504.0, 1510.0, 2000.0);
    } else if (ppmVal > 1504.0 && ppmVal <= 2504.0) {
        // 201-300 AQI | Purple | Very Unhealthy
        AQIvalue = map(ppmVal, 1504.0, 2504.0, 2010.0, 3000.0);
    } else if (ppmVal > 2504.0 && ppmVal <= 3504.0) {
        // 301-400 AQI | Marone | Hazardous
        AQIvalue = map(ppmVal, 2504.0, 3504.0, 3010.0, 4000.0);
    } else if (ppmVal > 3504.0 && ppmVal <= 5000.0) {
        // 401-500 AQI | Marone | Hazardous
        AQIvalue = map(ppmVal, 3504.0, 5000.0, 4010.0, 5000.0);
    }

    AQIvalue /= 10.0;
    return Math.round(AQIvalue);
}

function map(value, fromLow, fromHigh, toLow, toHigh) {
    return ((value - fromLow) / (fromHigh - fromLow)) * (toHigh - toLow) + toLow;
}


/*************** INTERACTION HELPERS **********************/
const mouse = {
    x: 0,
    y: 0,
};

// Add event listeners for mouse movement
document.addEventListener('mousemove', (event) => {
    mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
    mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

});